Disable-NetAdapterBinding -Name "*" -ComponentID ms_tcpip
Enable-NetAdapterBinding -Name "*" -ComponentID ms_tcpip6